<?php include "header.php";?>

<?php


if (isset($_POST['added_id'])) {

    $added_id = htmlspecialchars($_POST['added_id']);
    $idx = htmlspecialchars($_POST['idx']);

    $linkdata = DB::queryFirstRow("SELECT * FROM addedlink where added_id = %i and `user_id` = %i", $added_id, $idx);
    echo $linkdata['site_adress'];


} else {
    echo '<script type="text/javascript">
    <!--
    window.location = "linklerim"
    //-->
    </script>';
    exit;
} 

?>

<div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><?php echo $title ?> </a></li>
					</ol>
                </div>
                <!-- row -->


                <div class="row">

                <div class="col-xl-6 col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Link Ekle</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form method="post" action="system/l-save.php">
                                        <div class="form-group">
                                            <label class="text-label">Site Link:</label> 
                                            <input type="hidden" name="added_id" value="<?php echo $linkdata['added_id'];?>"?>
                                            <input type="text" name="site" class="form-control input-rounded" value="<?php echo $linkdata['site_adress']; ?>" placeholder="Site Link">
                                            <label class="text-label">Link Limiti:</label> 
                                            <input type="text" name="keyword" class="form-control input-rounded" value="<?php echo $linkdata['keyword']; ?>" placeholder="Link Limit">
                                        
                                            <br>
                                            <button type="submit" class="btn btn-primary">Linki Kaydet</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
                    


         </div>
         </div>
        </div>






        <script>
$( document ).ready(function() {
    $("[title='Nothing selected']").hide()
});
 </script>
<?php include "footer.php";?>