<?php include "header.php"; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active"><?php echo $title ?></a></li>
            </ol>
        </div>
        <!-- row -->


        <div class="row">


            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><i class="fas fa-link"></i> Toplu Link Değiştir</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" action="system/toplu-degistir.php">
                        Anahtar Kelime;
                        <input type="text" class="form-control input-rounded" name="kelime" placeholder="Anahtar Kelimeniz">
                        Site Adresi;
                        <input type="text" class="form-control input-rounded" name="site_adresi" name="site_adresi" placeholder="Site Adresiniz">
                        <button type="submit" class="btn btn-primary" name="topluekle">Toplu Değiştir</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->


</script>

<!--**********************************
    Footer start
***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">HacklinkSEO</a> 2024</p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->

<!--**********************************
   Support ticket button start
***********************************-->

<!--**********************************
   Support ticket button end
***********************************-->


</div>
<!--**********************************
Main wrapper end
***********************************-->

<!--**********************************
Scripts
***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/deznav-init.js"></script>

<!-- Datatable -->
<script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="js/plugins-init/datatables.init.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.control-btn').click(function(event) {  //on click
            $.post( "system/link-check.php", { site: $(this).data("site"), id: $(this).data("id")} );
            location.reload();
        });
        $('#selectall').click(function(event) {  //on click
            if(this.checked) { // check select status
                $(":checkbox").attr("checked", true);
            }else{
                $(":checkbox").attr("checked", false);
            }
        });

    });
</script>
</body>
<script>
    $( document ).ready(function() {
        $("[title='Nothing selected']").hide()
    });
</script>
<?php
if (@$_GET['durum']=="uzatildi") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'info',
            title: 'Link Başarılı Şekilde Uzatildi!',
        })

    </script>
<?php } ?>

<?php
if (@$_GET['durum']=="zaktif") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'info',
            title: 'Linkiniz Hali hazırda aktif!',
        })

    </script>
<?php } ?>

<?php
if (@$_GET['durum']=="bakiye") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'error',
            title: 'Bakiyeniz Yetersiz!',
            text: 'Lütfen Bakiye Yükleyiniz..!',
        })
    </script>
<?php } ?>
<?php
if (@$_GET['durum']=="duzenlendi") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'info',
            title: 'Link Başarılı Şekilde Düzenlendi.!',
            text: 'Link Başarılı Şekilde Düzenlendi..',
        })

    </script>
<?php } ?>
<?php
if (@$_GET['durum']=="hata") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'error',
            title: 'Bakiyeniz Yetersiz!',
            text: 'Lütfen Bakiye Yükleyiniz..!',
        })
    </script>
<?php } ?>
<?php
if (@$_GET['durum']=="limit") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'error',
            title: 'Link satın almak istediğiniz site max link limite ulaşmıştır!',
            text: 'Dilerseniz başka bir siteden link alabilirsiniz.!',
        })
    </script>
<?php } ?>
<?php
if (@$_GET['durum']=="refundok") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'info',
            title: 'Başarılı Bir şekilde iade sağlanmıştır!',
            text: 'Bakiyeniz ile yeni bir link satın alabilirsiniz!',
        })
    </script>
<?php } ?>
<?php
if (@$_GET['durum']=="refundhata") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'error',
            title: 'Geri ödeme işleminiz gerçekleştirilemedi!',
            text: 'Geri ödeme sadece ilk 3 gün içerisinde geçerlidir!',
        })
    </script>
<?php } ?>
<script>
    $( document ).ready(function() {
        $(".swal2-select").remove()
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.control-btn').click(function(event) {  //on click
            $.post( "system/pasif-sil.php", { id: $(this).data("id")} );
            location.reload();
        });
    });
</script>
<?php
if (@$_GET['durum']=="ok") { ?>
    <script type="text/javascript">
        Swal.fire({
            icon: 'info',
            title: 'Link Başarılı Şekilde Eklendi!',
            text: 'Lütfen Anahtar Kelimenizi ve Site Adresinizi Güncelleyin',
        })

    </script>
<?php } ?>
</html>