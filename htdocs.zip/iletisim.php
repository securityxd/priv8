<?php include "header.php"; ?>

<div class="content-body">
<div class="container-fluid">
<div class="page-titles">
   <ol class="breadcrumb">
      <li class="breadcrumb-item active"><?php echo $title ?> </a></li>
   </ol>
</div>
<div class="col-xl-12 col-lg-12 col-sm-12">
						<div class="card overflow-hidden">
							<div class="text-center p-3 overlay-box " style="background-image: url(images/big/img1.jpg);">
								<div class="profile-photo">
									<img src="images/profile/profile.png" width="100" class="img-fluid rounded-circle" alt="">
								</div>
								<h3 class="mt-3 mb-1 text-white">İletişim & Diğer Ödeme Yöntemleri</h3>
								<p class="text-white mb-0">Kripto harici Papara ve diğer ödeme yöntemleri için iletişime geçin. </p>
							</div>
							<ul class="list-group list-group-flush">
								<li class="list-group-item d-flex justify-content-between"><span class="mb-0">Skype:</span> <strong class="text-muted">live:.cid.880adef4d95dbf76</strong></li>
								<li class="list-group-item d-flex justify-content-between"><span class="mb-0">Whatsapp:</span> 		<strong class="text-muted">	</strong></li>
								<li class="list-group-item d-flex justify-content-between"><span class="mb-0">Telegram: </span> <strong class="text-muted">t.me/hacklinkpanel</strong></li>
							</ul>
                            
                        </div>
					</div>
   
   

</div>


</div>
</div>

<?php include "footer.php"; ?>