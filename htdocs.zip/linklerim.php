<?php include "header.php"; ?> 
<!--**********************************
   Content body start
   ***********************************-->
<div class="content-body">
   <div class="container-fluid">
      <div class="page-titles">
         <ol class="breadcrumb">
            <li class="breadcrumb-item active"><?php echo $title ?> </a></li>
         </ol>
      </div>
      <!-- row -->
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header">
                  <h4 class="card-title"><i class="fas fa-shopping-basket"></i> Satın Aldığınız Linkler</h4>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
                     <table id="xxxx" width="1410" class="display min-w850">
                        <thead>
                           <tr>
                             <th>Pasif Sil</th>
                              <th>Site Link</th>
                              <th>Aktif/Pasif</th>
                              <th>Linkiniz</th>
                              <th>Anahtar Kelimeniz</th>
                              <th>Kalan Gün</th>
                              <th>Düzenle</th>
                              <th>İade Et</th>
                              <th>S.Uzat</th>
                           </tr>
                        </thead>
                        <tbody>
                        
                           <?php
                              $results = DB::query("SELECT * FROM addedlink WHERE user_id=%i", $check_id);
                              foreach ($results as $row) { ?>
                           <tr>
                              <td>
                              <?php 

                                 $bitiyo1 = $row['bitisdate'];
                                 //system/link-check.php
                                 if (strtotime(date("Y/m/d")) > strtotime($bitiyo1)) {
                                   echo '
                                  <span data-id="'.$row['added_id'].'" id="sil_click" class="btn btn-danger control-btn btn-xs"><i class="fas fa-trash"></i> Sil</span>';
                                   }else {
                                     echo ' <a class="btn btn-primary btn-xs">Aktif</a>';          
                                    }
                               ?>                               
                              </td>

                              <td><?php echo $row['addedsite'] ?></td>
                              <td>
                                 <?php 
                                          
                                   $bitiyo1 = $row['bitisdate'];
     
                                    if (strtotime(date("Y/m/d")) <= strtotime($bitiyo1)) {
                                        echo '<span class="badge light badge-success"><i class="fas fa-smile-beam"></i> Link Aktif</span>';
                                      }else {
                                        echo '<span class="badge light badge-danger"><i class="fas fa-skull"></i> Link Pasif</span>'; 
                                      }
                                    
                                    ?>
                              </td>
                              
                              <td><strong><span class="badge light badge-warning"><?php echo $row['site_adress'] ?></span></strong></td>
                              <td><strong><span class="badge light badge-success"><?php echo $row['keyword'] ?></span></strong></td>
                              <td>
                              <?php
                               $bitiyo2 = strtotime($row['bitisdate']);
                               // echo $bitiyo2;
                               $tarih = strtotime(date("d.m.Y"));
                               // echo $tarih;
                               $fark = $bitiyo2 - $tarih;
                               $kalan = floor($fark / (60 * 60 * 24)) . " gün kaldı<br/>";
                               // echo $kalan
                               if ($kalan>=0) {
                                 echo '<strong><span class="badge light badge-success">'.$kalan.'</span></strong>';
                               }else {
                                 echo '<strong><span class="badge light badge-warning">Link Süresi Bitti</span></strong>';
                               }
                              ?>
                              </td>

                              <td>
                                 <div class="d-flex">
                                    <form method="post" action="link-duzenle">
                                       <input type="hidden" name="added_id" value="<?php echo $row['added_id'] ?>">
                                       <input type="hidden" name="idx" value="<?php echo $userdata['id'] ?>">
                                       <button type="sumbit" class="btn btn-success shadow btn-xs sharp mr-3"><i class="fas fa-pencil-alt"></i></button>
                                    </form>
                                 </div>
                              </td>
                              <td>
                                 <div class="d-flex">
                                    <form method="post" action="system/refund.php">
                                       <input type="hidden" name="added_id" value="<?php echo $row['added_id'] ?>">
                                       <button type="sumbit" class="btn btn-warning shadow btn-xs sharp"><i class="fas fa-sync-alt"></i></button>
                                    </form>
                                 </div>
                              </td>
                              <td>
                              <form method="post" action="system/link-uzat.php">
                                       <input type="hidden" name="added_id" value="<?php echo $row['added_id'] ?>">
                                       <button type="sumbit" class="btn btn-info shadow btn-xs sharp"><i class="fas fa-arrow-right"></i></button>
                              </form>
                              </td>
                           </tr>
                           <?php  } ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!--**********************************
   Content body end
   ***********************************-->
</script>
<!--**********************************
   Footer start
   ***********************************-->
<div class="footer">
   <div class="copyright">
      <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">HacklinkSEO</a> 2024</p>
   </div>
</div>
<!--**********************************
   Footer end
   ***********************************-->
<!--**********************************
   Support ticket button start
   ***********************************-->
<!--**********************************
   Support ticket button end
   ***********************************-->
</div>
<!--**********************************
   Main wrapper end
   ***********************************-->
<!--**********************************
   Scripts
   ***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/deznav-init.js"></script>
<!-- Datatable -->
<script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="js/plugins-init/datatables.init.js"></script>
</body>
<?php 
   if (@$_GET['durum']=="ok") { ?>
<script type="text/javascript">
   Swal.fire({
     icon: 'info',
     title: 'Link Başarılı Şekilde Eklendi!',
     text: 'Lütfen Anahtar Kelimenizi ve Site Adresinizi Güncelleyin',
   })
      
</script>
<?php } ?>

<?php 
   if (@$_GET['durum']=="uzatildi") { ?>
<script type="text/javascript">
   Swal.fire({
     icon: 'info',
     title: 'Link Başarılı Şekilde Uzatildi!',
   })
      
</script>
<?php } ?>

<?php 
   if (@$_GET['durum']=="zaktif") { ?>
<script type="text/javascript">
   Swal.fire({
     icon: 'info',
     title: 'Linkiniz Hali hazırda aktif!',
   })
      
</script>
<?php } ?>

<?php 
   if (@$_GET['durum']=="bakiye") { ?>
<script type="text/javascript">
   Swal.fire({
   icon: 'error',
   title: 'Bakiyeniz Yetersiz!',
   text: 'Lütfen Bakiye Yükleyiniz..!',
   })
</script>
<?php } ?>
<?php 
   if (@$_GET['durum']=="duzenlendi") { ?>
<script type="text/javascript">
   Swal.fire({
     icon: 'info',
     title: 'Link Başarılı Şekilde Düzenlendi.!',
     text: 'Link Başarılı Şekilde Düzenlendi..',
   })
      
</script>
<?php } ?>
<?php 
   if (@$_GET['durum']=="hata") { ?>
<script type="text/javascript">
   Swal.fire({
   icon: 'error',
   title: 'Bakiyeniz Yetersiz!',
   text: 'Lütfen Bakiye Yükleyiniz..!',
   })
</script>
<?php } ?>
<?php 
   if (@$_GET['durum']=="limit") { ?>
<script type="text/javascript">
   Swal.fire({
   icon: 'error',
   title: 'Link satın almak istediğiniz site max link limite ulaşmıştır!',
   text: 'Dilerseniz başka bir siteden link alabilirsiniz.!',
   })
</script>
<?php } ?>
<?php 
   if (@$_GET['durum']=="refundok") { ?>
<script type="text/javascript">
   Swal.fire({
   icon: 'info',
   title: 'Başarılı Bir şekilde iade sağlanmıştır!',
   text: 'Bakiyeniz ile yeni bir link satın alabilirsiniz!',
   })
</script>
<?php } ?>
<?php 
   if (@$_GET['durum']=="refundhata") { ?>
<script type="text/javascript">
   Swal.fire({
   icon: 'error',
   title: 'Geri ödeme işleminiz gerçekleştirilemedi!',
   text: 'Geri ödeme sadece ilk 3 gün içerisinde geçerlidir!',
   })
</script>
<?php } ?>
<script>
   $( document ).ready(function() {
    $(".swal2-select").remove()
   });
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('.control-btn').click(function(event) {  //on click
    $.post( "system/pasif-sil.php", { id: $(this).data("id")} );
       location.reload();
    });
});
</script>
</html>