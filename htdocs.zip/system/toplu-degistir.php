<?php 

error_reporting(2);

require_once "db.class.php";

if (isset($_SESSION['user'])) {
  echo "";
}else {
    header("location:index");
    exit;
}


if(isset($_POST)){
            $check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);
            $userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);
            $satinalan = htmlspecialchars($userdata['id']);

            // bakiye kontrol
            $bakiye = $userdata['balance'];

            if ($bakiye < 0.5) {
                header("location:../toplu-link-degistir?durum=bakiye");
                exit;
            }

            $siteniz = htmlspecialchars($_POST['site_adresi']);
            $kelime = htmlspecialchars($_POST['kelime']);
            $linkcode = '<a href="'. $siteniz . '"' . ' title="' . $kelime . '">' . $kelime . '</a>';
            $bakiye = $userdata['balance'];
            $harcananbakiye = $userdata['exbalance'];
            $tarih = date("Y/m/d");
            $bitistarih   = date('Y/m/d', strtotime('+30 days'));
            $sonrefund   = date('Y/m/d', strtotime('+3 days'));
        

          $added = DB::query("UPDATE addedlink SET site_adress=%s, keyword=%s, linkcode=%s WHERE user_id=%i", $siteniz, $kelime, $linkcode, $satinalan);

            if ($added) {


                header("location:../toplu-link-degistir?durum=ok");
            }


        
    $geldigi_sayfa = $_SERVER['HTTP_REFERER']; 
header("Refresh: 2; url=".$geldigi_sayfa."");
    

    }
   

?>

