<?php

	include('system/db.class.php');

	$check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);

	$userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);

	if ($userdata['admin']==1) {
		echo ":)"; 
	  }else {
		header("location:dashboard");
		exit;
	  }

	$results = DB::query("select * from links order by site_id DESC");

	foreach ($results as $row){		
		$id = $row['site_id'];
		$link = $row['siteadresi'];

		include "moz.php";
			
		$moz = json_decode($moz);
		$da = number_format($moz->pda,2);
		$pa = number_format($moz->upa,2);
		
		echo $da;
		echo $pa;
		
		DB::query("UPDATE links SET da=%s,pa=%s WHERE site_id=%i", $da, $pa, $id);

		sleep(1);
		echo "İşlem tamamlandı";
		
	}



?>