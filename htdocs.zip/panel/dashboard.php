<?php include "header.php"; ?>
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
					
					
                <div class="col-xl-3 col-lg-6 col-sm-6 col-xxl-4">
						<div class="widget-stat card bg-danger">
							<div class="card-body  p-4">
								<div class="media">
									<span class="mr-3">
                                          <i class="fas fa-link"></i>
									</span>
									<div class="media-body text-white text-right">
										<p class="mb-1">Havuzdaki Link Sayısı</p>
										<h3 class="text-white"><?php echo $linksayisi; ?></h3>
									</div>
								</div>
							</div>
						</div>
                    </div>
					<div class="col-xl-3 col-lg-6 col-sm-6 col-xxl-4">
						<div class="widget-stat card bg-success">
							<div class="card-body p-4">
								<div class="media">
									<span class="mr-3">
										<i class="flaticon-381-diamond"></i>
									</span>
									<div class="media-body text-white text-right">
										<p class="mb-1">Satın Aldığınız Linkler</p>
										<h3 class="text-white"><?php echo $satinalinan;?></h3>
									</div>
								</div>
							</div>
						</div>
                    </div>
					<div class="col-xl-3 col-lg-6 col-sm-6 col-xxl-4">
						<div class="widget-stat card bg-info">
							<div class="card-body p-4">
								<div class="media">
									<span class="mr-3">
										<i class="flaticon-381-heart"></i>
									</span>
									<div class="media-body text-white text-right">
										<p class="mb-1">Aldınız Aktif Linkleriniz</p>
										<h3 class="text-white"><?php echo $aktiflink;?></h3>
									</div>
								</div>
							</div>
						</div>
                    </div>
					<div class="col-xl-3 col-lg-6 col-sm-6 col-xxl-4">
						<div class="widget-stat card bg-primary">
							<div class="card-body p-4">
								<div class="media">
									<span class="mr-3">
									<i class="fas fa-dollar-sign"></i>
									</span>
									<div class="media-body text-white text-right">
										<p class="mb-1">Toplam Harcamanz</p>
										<h3 class="text-white"><?php echo $userdata['exbalance']?>₺</h3>
									</div>
								</div>
							</div>
						</div>
                    </div>
                       
					<div class="col-xl-12 col-lg-50">
                        <div class="card">
                            <div class="card-header border-0 pb-0">
                                <h4 class="card-title"><i class="fas fa-bullhorn"></i> Duyurular</h4>
                            </div>
                            <div class="card-body">
                                <div id="DZ_W_TimeLine" class="widget-timeline dz-scroll height370 ps ps--active-y">
                                    <ul class="timeline">
									<?php
                                            $results = DB::query("SELECT * FROM duyurular order by d_id DESC");
                                            foreach ($results as $row) { ?>
                                        <li>
                                            <div class="timeline-badge info">
                                            </div>
                                            <a class="timeline-panel text-muted">
                                            
                                                <span><?php echo $row['d_tarih'];?></span>
                                                <h6 class="mb-0"><?php echo $row['d_title'];?></h6>
												<p class="mb-0"><?php echo $row['d_icerik'];?></p>
                                            </a>
                                        </li>
										<?php  } ?>
                                        
                                    </ul>
                                <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 370px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 216px;"></div></div></div>
                            </div>
                        </div>
					</div>
					
					</div>
                    </div>
                    </div>
					
			
        <!--**********************************
            Content body end
        ***********************************-->

<?php include "footer.php"; ?>