<?php

include('system/db.class.php');

$check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);

	$userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);

if ($userdata['admin']==1) {
	echo ":)"; 
  }else {
	header("location:dashboard");
	exit;
  }

  
$results = DB::query("select * from links order by site_id DESC");

	foreach ($results as $row){		
					$id = $row['site_id'];
					$link = $row['siteadresi'];

					$alexa = simplexml_load_file('http://proxy-server.herokuapp.com/https://data.alexa.com/data?cli=10&url='.$link);
					$globalRank = number_format( (int) $alexa->SD->POPULARITY['TEXT'] );
					$countryCode = $alexa->SD->COUNTRY['CODE'];
					$countryName = $alexa->SD->COUNTRY['NAME'];
					$countryRank = number_format( (int) $alexa->SD->COUNTRY['RANK'] );
			
					DB::query("UPDATE links SET alexaglobal=%s ,alexacountry=%s WHERE site_id=%s", $globalRank, $countryRank, $id);
					echo "İşlem tamamlandı";
					sleep(1);
					 }

?>