<?php include "header.php"; ?>

<?php if ($userdata['admin']==1) { ?>





<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><?php echo $title ?> </a></li>
					</ol>
                </div>
                <!-- row -->


                <div class="row">
                    
                    
					<div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"><i class="fas fa-shopping-basket"></i> Müşterilerin Linkleri</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="xxxx" width="1410" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <td>Müşteri</td>
                                                <th>Site Adresi</th>
                                                <th>Müşterinin Sitesi</th>
                                                <th>Link Aldığı Kelime</th>
                                                <th>Bitiş Tarihi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $results = DB::query("SELECT * FROM `addedlink`");
                                            foreach ($results as $row) { ?>
                                            <tr>
                                                <td>
                                                @<?php  $row['user_id'];
                                                $musteridata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $row['user_id']);
                                                echo $musteridata['username']

                                                ?>

                                                </td>
                                                <td><?php echo $row['addedsite'] ?></td>
                                                <td><?php echo  $row['site_adress'] ?></td>
                                                <td><?php echo $row['keyword'] ?></td>
                                                <td><?php echo  $row['bitisdate'] ?></td>
                                            </tr>
                                          <?php  } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
      

        </script>

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">HacklinkSEO</a> 2024</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
    <!-- Datatable -->
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="js/plugins-init/datatables.init.js"></script>

</body>

</html>





<?php }else { ?>

<script type="text/javascript">

window.location = "https://hacklinkz.org/panel/index"

</script>

<?php }; ?>