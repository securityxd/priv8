<?php include "header.php"; ?>
<div class="content-body">
   <div class="container-fluid">
      <div class="page-titles">
         <ol class="breadcrumb">
            <li class="breadcrumb-item active"><?php echo $title ?> </a></li>
         </ol>
      </div>
      <div class="row">
         <div class="col-xl-4 col-lg-12 col-sm-12">
            <div class="card overflow-hidden">
               <div class="text-center p-5 overlay-box" style="background-image: url(images/big/img5.jpg);">
                                    <img src="system/tether-usdt-logo.png" width="100" class="img-fluid rounded-circle" alt="">
               <br>
               <h3 class="mt-3 mb-0 text-white">USDT Tether TRON(TRC-20) <br><br>TCf6tCYtW4AxhX1Jfk7An9N7JZGBqvnmYM</h3>
               </div>
               <div class="card-body">
                  <form action="system/worker.php" method="post">
                     <div class="row text-center">
                        <label class="text-label">Kullanıcı Adınız*</label>
                        <input type="text" name="adsoyad" class="form-control input-rounded" placeholder="Panel'e kayıt olurken seçtiğiniz kullanıcı adını buraya yazın.">
                        <label class="text-label">Ödenen miktar</label>
                        <input type="number" name="miktar" class="form-control input-rounded" placeholder="Miktar; Örnek 500₺">
                     </div>
               </div>
               <div class="card-footer mt-0">								
               <button name="bakiyebildir" type="submit" class="btn btn-primary btn-lg btn-block">Ödeme Bildir</button>		
               </div>
               </form>
            </div>
         </div>
         
      </div>
   </div>
</div>
<?php 
   if (@$_GET['durum']=="basarili") { ?>
<script type="text/javascript">
   Swal.fire({
     icon: 'info',
     title: 'Başarlı!',
     text: 'Ödeme Bildiriminiz Başarılı Şekilde Gerekleşti!',
   })
      
</script>
<?php } ?>
<?php 
   if (@$_GET['durum']=="hata") { ?>
<script type="text/javascript">
   Swal.fire({
     icon: 'warning',
     title: 'Yapma güzel kardeşim kırma sistemizi!',
     text: 'Abi yapma atma o trnağı inputa',
   })
      
</script>
<?php } ?>

<script>
$( document ).ready(function() {
    $("[title='Nothing selected']").hide()
});
 </script>
<?php include "footer.php"; ?>