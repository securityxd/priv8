<?php include "header.php";?>

<?php if ($userdata['admin']==1) { ?>

<?php


if (isset($_POST['d_duzenle'])) {

    $d_id = htmlspecialchars($_POST['d_duzenle']);

    $d_data = DB::queryFirstRow("SELECT * FROM duyurular where d_id = %i", $d_id);


} else {
    echo '<script type="text/javascript">
    <!--
    window.location = "linklerim"
    //-->
    </script>';
    exit;
} 

?>

<div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><?php echo $title ?> </a></li>
					</ol>
                </div>
                <!-- row -->


                <div class="row">

                <div class="col-xl-6 col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Duyuru Düzenle</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                 <form method="post" action="system/d-save.php">
                                        <div class="form-group">
                                            <label class="text-label">Duyuru Başlık:</label> 
                                            <input type="hidden" name="d_id" value="<?php echo $d_data['d_id'];?> ">
                                            <input type="text" name="d_baslik" class="form-control input-rounded" value="<?php echo $d_data['d_title']; ?>">
                                           
                                            <label class="text-label">Duyuru İçerik:</label> 
                                            <textarea type="text" name="d_icerik" class="form-control input"><?php echo $d_data['d_icerik']; ?></textarea>
                                            <br>
                                            <button type="submit" class="btn btn-primary">Duyuru Güncelle</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
                    


         </div>
         </div>
        </div>







<?php include "footer.php";?>



<?php }else { ?>

<script type="text/javascript">

window.location = "http://localhost/greenlink/"

</script>

<?php }; ?>