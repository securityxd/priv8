<?php include "header.php"; ?>

<?php if ($userdata['admin']==1) { ?>





<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><?php echo $title ?> </a></li>
					</ol>
                </div>
                <!-- row -->


                <div class="row">
                    
                    
					<div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"><i class="fas fa-shopping-basket"></i> Ödeme Bildirimleri</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="xxxx" width="1410" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <td>Müşteri</td>
                                                <th>Ad Soyad</th>
                                                <th>Miktar</th>
                                                <th>Tarih</th>
                                                <th>Onayla</th>
                                                <th>Sil</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $results = DB::query("SELECT * FROM `payments` WHERE onay=0");
                                            foreach ($results as $row) { ?>
                                            <tr>
                                                <td><img class="rounded-circle" width="25" src="images/papara.png" alt=""></td>
                                                <td>@<?php echo  $row['username'] ?></td>
                                                <td><?php echo $row['name'] ?></td>
                                                <td><strong><span class="badge light badge-warning"><?php echo $row['amount'] ?> ₺</span></strong></td>
                                                <td><?php echo $row['date'] ?></td>
                                                <td>
													<div class="d-flex">
                                                    <form action="system/a-worker.php" method="post">
                                                        <input type="hidden" name="onayid" value="<?php echo $row['id'] ?>">
                                                        <input type="hidden" name="username" value="<?php echo $row['username'] ?>">
                                                        <input type="hidden" name="amount" value="<?php echo $row['amount'] ?>">
                                                        <button type="submit" class="btn btn-success shadow btn-xs sharp mr-3"><i class="far fa-check-circle"></i></button>
													</div>	
                                                    </form>											
												</td>	
                                                <td>
                                                <div class="d-flex">
                                                    <form action="system/a-worker.php" method="post">
                                                        <input type="hidden" name="silid" value="<?php echo $row['id'] ?>">
														<button type="submit" class="btn btn-danger shadow btn-xs sharp mr-3"><i class="fas fa-trash-alt"></i></button>
													</div>	
                                                    </form>	
                                                </td>												
                                            </tr>
                                          <?php  } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
      

        </script>

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">HacklinkSEO</a> 2024</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>
	
    <!-- Datatable -->
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="js/plugins-init/datatables.init.js"></script>

</body>

</html>





<?php }else { ?>

<script type="text/javascript">

window.location = "http://hacklinkz.org/panel/index"

</script>

<?php }; ?>