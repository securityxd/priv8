<?php 


require_once 'db.class.php';

$check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);

$userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);

if ($userdata['admin']==1) {
    header("Refresh: 0; url=".$geldigi_sayfa."");
}else {
  header("location:dashboard");
  exit;
}


if (isset($_POST['silid'])) {

    $id = htmlspecialchars($_POST['silid']);
    
    $sil = DB::delete('payments', 'id=%s', $id);

    if ($sil) {

      header("location:../a-odemeler?durum=ok");
      exit;
    } else {
      header("location:../a-odemeler?durum=no");
      exit;
    }
    
  }


  if (isset($_POST['onayid'])) {

    $id = htmlspecialchars($_POST['onayid']);
    $username = htmlspecialchars($_POST['username']);
    $amount = htmlspecialchars($_POST['amount']);
    $onay = DB::query("UPDATE payments SET onay=1 WHERE id=%i", $id);
    if ($onay) {
      $userdata = DB::queryFirstRow("SELECT * FROM users where username = %s" , $username);
      $suanki = $userdata['balance'];
      $balance = DB::query("UPDATE users SET balance=%s WHERE username=%s", $amount+$suanki, $username);
      if ($balance) {
        header("location:../a-odemeler?durum=ok");
        exit;
      }

    } else {
      header("location:../a-odemeler?durum=no");
      exit;

    }
    exit;
  }


  if (isset($_POST['site_link'])) {

    $link = htmlspecialchars($_POST['site_link']);
    $link_limit = htmlspecialchars($_POST['link_limit']);
    $link_fiyat = htmlspecialchars($_POST['link_fiyat']);
    $alexa = simplexml_load_file('http://proxy-server.herokuapp.com/http://data.alexa.com/data?cli=10&url='.$link);
    $globalRank = number_format( (int) $alexa->SD->POPULARITY['TEXT'] );
    $countryCode = $alexa->SD->COUNTRY['CODE'];
    $countryRank = number_format( (int) $alexa->SD->COUNTRY['RANK'] );

    $link_ekle = DB::insert('links', [
      "siteadresi" => "$link",
      "maxlink" => "$link_limit",
      "alexaglobal" => "$globalRank",
      "alexacountry" => "$countryRank",
      "fiyat" => "$link_fiyat"]);

      if ($link_ekle) {
        header("location:../a-link-ekle?durum=ok");
      }else {
        header("location:../a-link-ekle?durum=hata");
      }
    
    
  
  }


  if (isset($_POST['d_baslik'])) {

    $d_baslik = htmlspecialchars($_POST['d_baslik']);
    $d_icerik = htmlspecialchars($_POST['d_icerik']);
    $tarih = date("Y/m/d");

    $duyuruekle = DB::insert('duyurular', [
      "d_title" => "$d_baslik",
      "d_tarih" => "$tarih",
      "d_icerik" => "$d_icerik"]);

      if ($duyuruekle) {
        header("location:../a-duyuru-ekle?durum=ok");
      }else {
        header("location:../a-duyuru-ekle?durum=hata");
      }
    
    
  
  }

  if (isset($_POST['d_silid'])) {

    $id = htmlspecialchars($_POST['d_silid']);
    
    $sil = DB::query("DELETE FROM duyurular WHERE d_id=%s", $id);

    if ($sil) {

      header("location:../a-duyurular?durum=silindi");
      exit;
    } else {
      header("location:../a-duyurular?durum=hata");
      exit;
    }
    
  }



?>

