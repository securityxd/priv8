<?php

error_reporting(0);

require_once "db.class.php";

if (isset($_SESSION['user'])) {
  echo "";
}else {
    header("location:index");
    exit;
}


if (isset($_POST['added_id'])) {

    $check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);

    $userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);

    $linkid = htmlspecialchars($_POST['added_id']);

    $linkdata = DB::queryFirstRow("SELECT * FROM addedlink where added_id = %i" , $linkid);

    $bitiyo = $linkdata['sonrefund'];



    if (strtotime(date("Y/m/d")) <= strtotime($bitiyo)) {
        
        $refund = $linkdata['fiyat'];
        $suanki = $userdata['balance'];

        $harcananbakiye = $userdata['exbalance'];


        $linkdatacek = DB::queryFirstField("SELECT * FROM links WHERE site_id=%s", $linkdata['site_id']);

        $bakiyeyukle = DB::query("UPDATE users SET balance=%s WHERE id=%s", $refund+$suanki, $check_id);

        $exbakiyeyukle = DB::query("UPDATE users SET exbalance=%s WHERE id=%s", $refund-$harcananbakiye, $check_id);


        $linkdata = DB::queryFirstRow("SELECT * FROM links where site_id = %s" , $linkdata['site_id']);
        $linklimit = $linkdata['maxlink'];
        $topla = $linklimit+1;

        $limitguncelle = DB::query("UPDATE links SET maxlink=%s WHERE site_id=%s", $topla, $linkdata['site_id']);

        if ($bakiyeyukle) {
            
            $sil = DB::query("DELETE FROM addedlink WHERE added_id=%i", $linkid);
            
            if ($sil) {
                header("location:../linklerim?durum=refundok");
                exit;
            }else {
                header("location:../linklerim?durum=refundhata");
                exit;
            }

        }


    }else {
        header("location:../linklerim?durum=refundhata");
        exit;
    }
}



?>