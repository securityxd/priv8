<?php

require_once "db.class.php";

if (isset($_SESSION['user'])) {
  echo "";
}else {
    header("location:index");
    exit;
}


if ($_POST) {

    $check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);

    $userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);

    $bakiye = $userdata['balance'];

    $added_id = $_POST['added_id'];

    $linkdata = DB::queryFirstRow("SELECT * FROM addedlink where added_id = %i" , $added_id);

    $tarih = date("Y/m/d");

    $satinalan = htmlspecialchars($userdata['id']);

    $bakiye = $userdata['balance'];
    $harcananbakiye = $userdata['exbalance'];
    $bitistarih   = date('Y/m/d', strtotime('+30 days'));
    $fiyat = $linkdata['fiyat'];
    $bitiyo1 = $linkdata['bitisdate'];

    if (strtotime(date("Y/m/d")) >= strtotime($bitiyo1)) {

    if ($bakiye>=$fiyat) {

        $uzat = DB::Update('addedlink', [
            'bitisdate' => "$bitistarih"
          ], "added_id=%i", $added_id);


        if ($uzat) {

            $dusukbakiye = $bakiye-$fiyat;

              $bakiyedus = DB::insertUpdate('users', [
                  'id' => "$satinalan", 
                  'balance' => "$bakiye"
                ], [
                  'balance' => "$dusukbakiye"
                ]);
        
                $harcananbakiyesss = $harcananbakiye+$fiyat;
        
                $exbalance = DB::insertUpdate('users', [
                  'id' => "$satinalan", 
                  'exbalance' => "$bakiye"
                ], [
                  'exbalance' => "$harcananbakiyesss"
                ]);

                header("location:../linklerim?durum=uzatildi");
                
        }

}else {
  header("location:../linklerim?durum=bakiye");
}

}else {
    header("location:../linklerim?durum=zaktif");
    exit();
}

}

?>