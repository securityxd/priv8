<?php

error_reporting(0);
require_once "db.class.php";

$check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);

	$userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);



if ($userdata['admin']==1) {
    echo ":)"; 
  }else {
    header("location:dashboard");
    exit;
  }


if (isset($_POST['d_id'])) {

    $id = htmlspecialchars($_POST['d_id']);
    $baslik = htmlspecialchars($_POST['d_baslik']);
    $icerik = htmlspecialchars($_POST['d_icerik']);
    $tarih = date("Y/m/d");


    $save = DB::insertUpdate('duyurular', [
        'd_id' => "$id",
        'd_title' => "$baslik",
        'd_icerik' => "$icerik",
        'd_tarih' => "$tarih"
      ]);

      if ($save) {
        header("location:../a-duyurular?durum=duzenlendi");
        exit;
      }else {
        header("location:../a-duyurular?durum=hata");
        exit;
      }
}




?>