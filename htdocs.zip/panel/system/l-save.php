<?php

error_reporting(0);

require_once "db.class.php";

if (isset($_SESSION['user'])) {
  echo "";
}else {
    header("location:index");
    exit;
}


if (isset($_POST['site'])) {

    $id = htmlspecialchars($_POST['added_id']);
    $site = htmlspecialchars($_POST['site']);
    $keyword = htmlspecialchars($_POST['keyword']);
    $linkcode = '<a href="'. $site . '"' . ' title="' . $keyword . '">' . $keyword . '</a>';

    $save = DB::query("UPDATE addedlink SET site_adress=%s, keyword=%s, linkcode=%s WHERE added_id=%s", $site, $keyword, $linkcode, $id);


      if ($save) {
        header("location:../linklerim?durum=duzenlendi");
        exit;
      }else {
        header("location:../linklerim?durum=hata");
        exit;
      }
}

header("location:../");
  exit();



?>