<?php

error_reporting(0);

require_once "db.class.php";

if (isset($_SESSION['user'])) {
  echo "";
}else {
    header("location:index");
    exit;
}
$check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);


if (isset($_POST['id'])) {

    $id = htmlspecialchars($_POST['id']);
    // echo $check_id;
    $results = DB::query("SELECT * FROM addedlink WHERE added_id=%i AND user_id=%i", $id, $check_id);
    // print_r($results);
    $bitiyo1 = $results['bitisdate'];
    if (strtotime(date("Y/m/d")) > strtotime($bitiyo1))  {

        $sil = DB::query("DELETE FROM addedlink WHERE added_id=%i", $id);
        if ($sil) {
            header("location:../linklerim?durum=silindi");
        }else {
            header("location:../linklerim?durum=hata1");   
        }
        
    }else {
        echo "abiii burda başkasının linkini silecek biri yok sanıyordum yapma be :("; 
    }
    
}


?>