<?php 

error_reporting(0);

require_once "db.class.php";

if (isset($_SESSION['user'])) {
  echo "";
}else {
    header("location:index");
    exit;
}


if (isset($_POST['id'])) {
    
    $check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);
    $userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);
    $buylink = htmlspecialchars($_POST['id']);
    $buydata = DB::queryFirstRow("SELECT * FROM links where site_id = %i" , $buylink);
    $fiyat = htmlspecialchars($buydata['fiyat']);
    $linklimitcheck = htmlspecialchars($buydata['maxlink']);
    $siteadresi = htmlspecialchars($buydata['siteadresi']);
    $satinalan = htmlspecialchars($userdata['id']);
    $siteniz = "https://www.siteniz.org";
    $kelime = "anahtar kelimeniz";
    $linkcode = '<a href="'. $siteniz . '"' . ' title="' . $kelime . '">' . $kelime . '</a>';
    $bakiye = $userdata['balance'];
    $harcananbakiye = $userdata['exbalance'];
    $tarih = date("Y/m/d");
    $bitistarih   = date('Y/m/d', strtotime('+30 days'));
    $sonrefund   = date('Y/m/d', strtotime('+3 days'));

  if ($linklimitcheck>0) {

    if ($bakiye>=$fiyat) {
      $dusukbakiye = $bakiye-$fiyat;
      $bakiyedus = DB::insertUpdate('users', [
          'id' => "$satinalan", 
          'balance' => "$bakiye"
        ], [
          'balance' => "$dusukbakiye"
        ]);

        $harcananbakiyesss = $harcananbakiye+$fiyat;
        
        $exbalance = DB::insertUpdate('users', [
          'id' => "$satinalan", 
          'exbalance' => "$bakiye"
        ], [
          'exbalance' => "$harcananbakiyesss"
        ]);

        if ($bakiyedus) {
          $added = DB::insert('addedlink', [
              'user_id' => "$satinalan",
              'site_id' => "$buylink",
              'site_adress' => "$siteniz",
              'keyword' => "$kelime",
              'linkcode' => "$linkcode",
              'addeddate' => "$tarih",
              'bitisdate' => "$bitistarih",
              'sonrefund' => "$sonrefund",
              'fiyat' => "$fiyat",
              'addedsite' => "$siteadresi"
            ]);

            if ($added) {

              $linkdata = DB::queryFirstRow("SELECT * FROM links where site_id = %s" , $buylink);
              $linklimit = $linkdata['maxlink'];
              $eksi = $linklimit-1;
              
              DB::insertUpdate('links', [
                  'site_id' => "$buylink",
                  'maxlink' => "$linklimit",
                  'maxlink' => "$eksi"
                ]);

                header("location:../linklerim?durum=ok");
                exit;

            }

        }else {
            echo "bir hata var bakiyedus sonrası";
            exit;
        }
  }else {
      header("location:../linklerim?durum=bakiye");
      exit;
  }
  }else {
    header("location:../linklerim?durum=limit");
    exit;
  }
}else {
    echo '<script type="text/javascript">

    window.location = "http://localhost/greenlink/linklerim"
    
    </script>';
    exit;
}