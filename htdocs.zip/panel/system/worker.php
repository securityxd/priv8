<?php 
// https://www.youtube.com/watch?v=ArxCH9gr6wI :)))))))))))))

error_reporting(0);

require_once "db.class.php";


if (isset($_SESSION['user'])) {
    echo "";
  }else {
      header("location:index");
      exit;
  }

if (isset($_POST['bakiyebildir']) and $_POST['adsoyad']!="") {

    $check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);
    $userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);
    $adsoyad =htmlspecialchars($_POST['adsoyad']);
    $miktar =htmlspecialchars($_POST['miktar']);
    $username = $userdata['username'];
    $tarih = htmlspecialchars(date('d.m.Y H:i:s'));

    DB::insert('payments', [
        'username' => "$username",
        'name' => "$adsoyad",
        'amount' => "$miktar",
        'date' => "$tarih"
      ]);
      header("Location: ../bakiye?durum=basarili");
      exit;
      
}else {
    header("location: ../bakiye?durum=hata");
    exit;
}


