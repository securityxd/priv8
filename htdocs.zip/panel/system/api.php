<?php

// error_reporting(0);

// https://www.youtube.com/watch?v=ArxCH9gr6wI :)))))))))))))


error_reporting(0);
require_once "db.class.php";
      
/**********************LOGIN**********************************/

      if (!empty($_POST['username']) and !empty($_POST['password'])) {
                      
        $user =htmlspecialchars($_POST['username']);
        $pass =sha1(htmlspecialchars($_POST['password']));
        
        $check = DB::queryFirstRow("SELECT * FROM users where username = %s AND password = %s", $user, $pass);
        if (!empty($check)) {
          $_SESSION['user']=$user;
          $_SESSION['pass']=$pass;
          header("Location: ../dashboard");
          exit;
        }else{
          header("location:../index?durum=sifre");
          exit;
        }
        exit;
      }else {
        header("location:../index");
      }

/**********************Register**********************************/


if (!empty($_POST['r_user']) and !empty($_POST['r_pass'])) {

  $r_user=htmlspecialchars($_POST['r_user']);

  $r_pass=sha1(htmlspecialchars($_POST['r_pass']));

    $r_register_check = DB::queryFirstRow("SELECT * FROM users where username = %s", $r_user);
    
      if ($r_register_check!=0) {
        header("location:../register?durum=uye");
      }else{
        $r_register = DB::insert('users', [
          "username" => "$r_user",
          "password" => "$r_pass"
        ]);
        if ($r_register) {
          header("location:../index?durum=basarili");
          exit;
        }else{
          header("location:../register?durum=hata");
          exit;
        }
      }
  }else{
    header("location:../register");
  
    
}

if (condition) {
  # code...
}

$site = $_POST['site'];
$query = $db->prepare('SELECT id FROM pasifler WHERE site_adresi = ?');
$param = array($site);
$query->execute($site);
if ($query->rowCount()) echo "$site zaten var";

if ($query->rowCount()) {
  echo "$site zaten var";
}else {
  $sitedata = htmlspecialchars($_POST["site"]);
  $tarih = date('d.m.Y H:i:s');
  $sql = "INSERT INTO pasifler (pasif_site, tarih) VALUES (?,?)";
  $db->prepare($sql)->execute([$sitedata, $tarih]);
}

?>