<?php include "header.php"; ?>

<?php if ($userdata['admin']==1) { ?>





<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><?php echo $title ?> </a></li>
					</ol>
                </div>
                <!-- row -->


                <div class="row">

                <div class="col-xl-6 col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Link Ekle</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form method="post" action="system/a-worker.php">
                                        <div class="form-group">
                                            <label class="text-label">Duyuru Başlık:</label> 
                                            <input type="text" name="d_baslik" class="form-control input-rounded" placeholder="Site Link">
                                           
                                            <label class="text-label">Duyuru İçerik:</label> 
                                            <textarea type="text" name="d_icerik" class="form-control input" placeholder="Link Limit"></textarea>
                                            <br>
                                            <button type="submit" class="btn btn-primary">Duyuru Yayınla</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
          


         </div>
         </div>
        </div>
        
        </div>
         </div>
        </div>

        <script>hljs.initHighlightingOnLoad();</script>


<?php }else { ?>

<script type="text/javascript">

window.location = "http://localhost/greenlink/"

</script>

<?php }; ?>



<?php 
if (@$_GET['durum']=="ok") { ?>
  <script type="text/javascript">
Swal.fire({
  icon: 'info',
  title: 'Başarılı!',
  text: 'Link Eklendi sayın amdin bey!',
})
   </script>
 <?php } ?>

 <?php 
if (@$_GET['durum']=="hata") { ?>
  <script type="text/javascript">
Swal.fire({
  icon: 'warning',
  title: 'Yapma güzel kardeşim kırma sistemizi!',
  text: 'Abi yapma atma o tırnağı inputa',
})
   </script>
 <?php } ?>

 <script>
$( document ).ready(function() {
    $("[title='Nothing selected']").hide()
});
 </script>

<?php include "footer.php";?>