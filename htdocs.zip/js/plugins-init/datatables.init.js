$(document).ready(function() {
   $('#xxxx').DataTable( {
		"paging":   false,
		"searching": true,
        "ordering": true,
        "info":     true,
        "responsive": true
        
    } );
 
} );
