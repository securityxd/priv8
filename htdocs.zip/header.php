<?php

require "system/db.class.php";

if (isset($_SESSION['user'])) {
  echo "";
}else {
    header("location:index");
    exit;
}

$check_id = DB::queryFirstField("SELECT id FROM users WHERE username=%s", $_SESSION['user']);

$userdata = DB::queryFirstRow("SELECT * FROM users where id = %s" , $check_id);


 $title = basename($_SERVER['SCRIPT_FILENAME'], '.php');

 $title = str_replace('_', ' ', $title);

 if (strtolower($title) == 'index') {
 $title = 'home';
 }
 $title = ucwords($title);


 $linksayisi = DB::queryFirstField("SELECT COUNT(*) FROM links");

$satinalinan = DB::queryFirstField("SELECT COUNT(*) FROM addedlink WHERE user_id = %i", $check_id);

$tarih = date("Y/m/d");

$aktiflink = DB::queryFirstField("SELECT COUNT(*) FROM addedlink WHERE user_id = %i and bitisdate >= %s", $check_id, $tarih);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Hacklink Panel - <?php echo $title ?> </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
	<link href="vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="../../cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.18.5/styles/atom-one-dark.min.css">
<style>
.wrap
{
    width: 320px;
    height: 192px;
    padding: 0;
    overflow: hidden;
}

.frame
{
    width: 1280px;
    height: 786px;
    border: 0;

    -ms-transform: scale(0.25);
    -moz-transform: scale(0.25);
    -o-transform: scale(0.25);
    -webkit-transform: scale(0.25);
    transform: scale(0.25);

    -ms-transform-origin: 0 0;
    -moz-transform-origin: 0 0;
    -o-transform-origin: 0 0;
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
}

</style>

<script type="text/javascript">
        function zoom() {
            document.body.style.zoom = "89%" 
        }
</script>

<body onload="zoom()">

</head>
<body>
    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="dashboard" class="brand-logo">
                <!--<img src="images/logo.png" alt="">!-->
               <div class="pwo">HACKLINK</div>
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="dashboard_bar">
                            <?php echo $title ?>

                            </div>
                        </div>
                        <ul class="navbar-nav header-right">
							
							<li class="nav-item">
								<a class="btn btn-primary  d-md-block d-none" href="#">
									</i>Bakiyeniz: <?php echo $userdata['balance']?> ₺
								</a>
							</li>
                            
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="javascript:;" role="button" data-toggle="dropdown">
                                    <img src="images/profile/12.png" width="20" alt=""/>
									<div class="header-info">
										<span>@<?php echo htmlspecialchars($_SESSION['user']) ;?><i class="fa fa-caret-down ml-3" aria-hidden="true"></i></span>
									</div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="logout" class="dropdown-item ai-icon">
                                        <svg id="icon-logout" xmlns="http://www.w3.org/2000/svg" class="text-danger" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                                        <span class="ml-2">Çıkış Yap </span>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li>
						<a href="dashboard" >
							<i class="fas fa-home"></i>
							<span class="nav-text">Dashboard</span>
						</a>
					</li>
					<li>
						<a href="link-market" >
							<i class="fas fa-link"></i>
							
							<span class="nav-text">Link Market</span>
						</a>
					</li>
					
									<li>
						<a href="https://panel.hacklinkz.org/seo/backlink.txt" >
							<i class="fas fa-link"></i>
							
							<span class="nav-text">Otokod Link Listesi Footer + Tanıtım Link (400 Site). Güncelleniyor..</span>
						</a>
					</li>
					
					<li>
						<a href="linklerim">
							<i class="fas fa-shopping-basket"></i>
							<span class="nav-text">Satn Aldığınz Linkler</span>
						</a>
					</li>
                    <li>
                        <a href="toplu-link-degistir">
                            <i class="fas fa-shopping-basket"></i>
                            <span class="nav-text">Toplu Link Değiştir</span>
                        </a>
                    </li>
					<li>
						<a href="bakiye" >
							<i class="fa fa-lira-sign"></i>
							<span class="nav-text">Bakiye işlemleri</span>
						</a>
					</li>
					<li>
					<!--	<a href="iletisim" >
							<i class="fab fa-whatsapp"></i>
							<span class="nav-text">iletiim</span>
						</a> !-->
					</li>
					<?php if ($userdata['admin']==1) {
						echo '<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-networking"></i>
                        <span class="nav-text">Admin Panel</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="a-duyurular">Duyurular</a></li>
                        <li><a href="a-duyuru-ekle">Duyuru Ekle</a></li>
                        <li><a href="a-musteriler">Müşteriler</a></li>
                        <li><a href="a-link-ekle">Link Ekle</a></li>
                        <li><a href="a-linkler">Linkler</a></li>
                        <li><a href="a-musterilerin-linkleri">Müşterilerin Linkleri</a></li>
                        <li><a href="#">Onay Bekleyen Ödemeler(KALDIRILDI)</a></li>
                        <li><a href="#">Da Pa Güncelle(KALDIRILDI)</a></li>
                        <li><a href="#">Alexa Rank Güncelle(KALDIRILDI)</a></li>
                    </ul>
                </li>';
					};	
					?>                    
                </ul>
            
				<div class="plus-box">
					<p class="fs-16 font-w500 mb-1">Çıkış Yap</p>
					<a class="text-white fs-26" href="logout"><i class="las la-long-arrow-alt-right"></i></a>
				</div>
				<div class="copyright">
					<p>Made with <i class="fa fa-heart text-danger"></i> by hacklink</p>
				</div>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->