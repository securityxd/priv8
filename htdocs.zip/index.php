<?php

require "system/db.class.php";

if (isset($_SESSION['user'])) {
    header("location:dashboard");
      exit;
  }else {
     
  }

?>

<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Hacklink panel - Hacklink satın al, Backlink paketleri</title>
    <meta name="description" content="Hacklink panel sayesinde tek bir tık ile dilediğiniz kadar backlink alabileceksiniz. Kaliteli ve etkili linklerde sizde yükselin."/>
    <meta name="keywords" content="hacklink panel, hacklink, hacklink satın al, backlink"/>

    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <p><h3 class="text-center mb-4">LOGIN!</h3></p>
									<br>
                                    <form action="system/api.php" method="post"> 
                                        <div class="form-group">
                                            <label class="mb-1"><strong>&nbsp;&nbsp;Kullanıcı Adı</strong></label>
                                            <input name="username" type="text" class="form-control" placeholder="Kullanıcı adınız..">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1"><strong>&nbsp;&nbsp;Şifre</strong></label>
                                            <input name="password" type="password" class="form-control" placeholder="Şifreniz..">
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">Giriş Yap</button>
                                        </div>
                                    </form>
									<br><br>
                                    <div class="new-account mt-3">
                                        <center><p>Panele Üyelikler ADMİN tarafından yapılmaktadır. Kayıt işlemi için iletişime geçin..<br></p></center>
                                        <center><p>SKYPE : live:.cid.880adef4d95dbf76</p></center>
                                        <center><p>Telegram : blckhatseo</p></center>
                                        <center><p><a href="https://www.hacklinkz.org/category/hacklink/">Hacklink Blog</a></p></center>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/deznav-init.js"></script>
  
</body>
 <?php 
if (@$_GET['durum']=="sifre") { ?>
  <script type="text/javascript">
   Swal.fire({
  icon: 'error',
  title: 'Şifreniz veya Kullanc Adınz Hatalı',
  text: 'Ltfen tekrar deneyin!',
})
 </script>
 <?php } ?>

 <?php 
if (@$_GET['durum']=="basarili") { ?>
  <script type="text/javascript">
   Swal.fire({
  icon: 'info',
  title: 'Başarıl bir ekilde Üye Oldunuz!',
  text: 'GreenLink Paneline Hoş geldiniz!',
})
 </script>
 <?php } ?>

<script>
   $( document ).ready(function() {
    $(".swal2-select").remove()
   });
</script>
</html>