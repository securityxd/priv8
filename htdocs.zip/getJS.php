<?php

require_once "system/db.class.php";

$site = $_GET['id'];

$results = DB::query("SELECT * FROM addedlink WHERE site_id=%i" , $site);

foreach ($results as $row) {

  $bitiyo = $row['bitisdate'];
  if (strtotime(date("Y/m/d")) < strtotime($bitiyo)) {

    $url = $row['site_adress'];
    $keyword = $row['keyword'];
    echo<<<EOF
    var a = document.createElement('a');
    var linkText = document.createTextNode("$keyword");
    a.appendChild(linkText);
    a.title = "$keyword";
    a.href = "$url";
    a.style = "overflow: auto; position: fixed; height: 0pt; width: 0pt";
    document.body.appendChild(a);
EOF;
  }
}
?>
