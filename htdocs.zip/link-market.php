<?php include "header.php"; ?>

<!--**********************************
    Content body start
***********************************-->
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active"><?php echo $title ?></a></li>
            </ol>
        </div>
        <!-- row -->


        <div class="row">
            
            
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><i class="fas fa-link"></i> Site Listesi</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                        <form method="post" action="system/toplu-ekle.php">
                            <table id="xxxx" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th><input id="selectall" type="checkbox"></th>
                                       <!--<th>Kontrol Et</th> !-->
                                        <th>Aktif/Pasif</th>
                                        <td>Fiyat</td>
                                        <th>Site Link</th>
                                        <th>Da</th>
                                        <th>Pa</th>
                                        <th>Link Limiti</th>
                                        <th>Siteyi G</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $results = DB::query("SELECT * FROM links");
                                    foreach ($results as $row) { ?>
                                    <tr>
                                        

                                        <td>
                                        <input type="checkbox" name="ekle[]" value="<?php echo $row['site_id']?>">
                                        

                                        </td>
                                       
                                                <td>
                                                
                                                <?php
                                                     if ($row['durum'] == 1) {
                                                        echo '<span class="badge dark  badge-success"><i class="fas fa-smile-beam"></i> Link Aktif</span>';
                                                      }else {
                                                        echo '<span class="badge dark badge-danger"><i class="fas fa-skull"></i> Link Pasif</span>';
                                                      }
                                                ?>

                                                
                                                </td>

                                        <td><?php echo $row['fiyat'];?>₺</td>
                                        <td>
                                        <?php
                                        
                                        if ($userdata['balance']>0) {
                                            echo $row['siteadresi'];
                                        }else {
                                            echo '<a href="bakiye"><span class="badge light badge-warning">Linkleri Görebilmek için bakiye Yüklemelisiniz.</span></a>';
                                        }

                                        ?>
                                        
                                        </td>
                                        </td>
                                        <td><?php echo $row['da'];?></td>
                                        <td><?php echo $row['pa'];?></td>
                                        <td><strong><span class="badge dark badge-success"><?php echo $row['maxlink'];?></span></strong></td>	
                                        <td>
                                            <?php
                                        
                                            if ($userdata['balance']>0) {
                                                echo '<a target="_blank" href="'. '' . $row['siteadresi'] . '" class="btn btn-info shadow btn-xs sharp"><i class="fas fa-external-link-alt"></i></a>';
                                            }else {
                                                echo '<a href="bakiye" class="btn btn-info shadow btn-xs sharp"><i class="fas fa-external-link-alt"></i></a>';
                                            }

                                            ?>
                                                
                                        </td>											
                                    </tr>
                                    
                                    <?php  } ?>
                                </tbody>
                                
                            </table>
                           
                                       
                        </div>
                        <br>
                        Anahtar Kelime;
                        <input type="text" class="form-control input-rounded" name="kelime" placeholder="Anahtar Kelimeniz">
                        Site Adresi;
                        <input type="text" class="form-control input-rounded" name="site_adresi" name="site_adresi" placeholder="Site Adresiniz">
                        <button type="submit" class="btn btn-primary" name="topluekle">Toplu Ekle</button>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->


</script>

<!--**********************************
    Footer start
***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">HacklinkSEO</a> 2024</p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->

<!--**********************************
   Support ticket button start
***********************************-->

<!--**********************************
   Support ticket button end
***********************************-->


</div>
<!--**********************************
Main wrapper end
***********************************-->

<!--**********************************
Scripts
***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/deznav-init.js"></script>

<!-- Datatable -->
<script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="js/plugins-init/datatables.init.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('.control-btn').click(function(event) {  //on click
    $.post( "system/link-check.php", { site: $(this).data("site"), id: $(this).data("id")} );
        location.reload();
    });
    $('#selectall').click(function(event) {  //on click
        if(this.checked) { // check select status
            $(":checkbox").attr("checked", true);
        }else{
             $(":checkbox").attr("checked", false);
        }
    });
   
});
</script>
</body>
<script>
$( document ).ready(function() {
$("[title='Nothing selected']").hide()
});
</script>

</html>